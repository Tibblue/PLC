import fileinput
import regex as re
from collections import Counter, defaultdict
import random
# a)


def upper_repl(match):
	return match.group(0) + match.group(1).upper()

def fix_sent_start(tmin):
	aux = re.sub(r'^(\s*)(\p{Ll})', lambda x: x[1] + x[2].upper(), tmin)
	tmax = re.sub(r'(?<=[?!.])(\s*)(\p{Ll})', lambda x: x[1] + x[2].upper(), aux)

	return tmax

# b)

ocorrencias = defaultdict(Counter)

def build(tg):
	list_tg = re.split(r'[\p{punct}\s]+', tg)

	for w in list_tg:
		ocorrencias[w.lower()][w] += 1

	return ocorrencias

# c) extra - corrigir texto usando o dicionário construído

texto_tofix = "um texto com nomes próprios e outras cenas tipo nomes e isso outras"

def correct(tg, tofix):
	texto_fixed = fix_sent_start(tofix)
	dictionary = build(tg)
	result = re.sub(r'\b(\p{L}+)\b', lambda x: choose_alt(x[1], dictionary), texto_fixed)
	print(texto_fixed)
	return result


def choose_alt(word, dictionary):
	word_norm = word.lower()
	if word in dictionary[word_norm]:
		return word
	else:
		return dictionary[word_norm].most_common()[0][0]


print(fix_sent_start("ola tudo bem. e contigo. tá tudo bem"))
print(build("Um texto com Nomes Próprios e outras cenas tipo nOmes e isso Outras"))
print(correct("Um texto com Nomes Próprios e outras cenas tipo nOmes e isso Outras", texto_tofix))