import regex as re

t1 = "As inundações provocaram graves damnos na pharmácia."
t2 = "As inundações provocaram graves danos na farmácia."

def find_corresp(t1, t2):
	dictionary = {}
	list_t1 = re.split(r'[\p{punct}|\s]+', t1)
	list_t2 = re.split(r'[\p{punct}|\s]+', t2)

	for i in range(0, len(list_t1)):
		if list_t1[i] != list_t2[i]:
			dictionary[list_t1[i]] = list_t2[i]

	return dictionary


print(find_corresp(t1, t2))