import regex as re

nome = "Daniel Fernandes"

polaridade = {
    'muito': 1,
    'bonito': 1,
    'sem': -1,
    'duvida': -1,
    'que': 0,
    'decidiu': 0,
    'dar': 1,
    'um': 0,
    'mergulhito': 1,
    'no': 0,
    'Helena': -1,
    'estudava': -1,
    'com': 0,
    'o': 0,
    'este': 0,
    'último': 1,
    'era': 1,
    'uma': 0,
    }
noticias = ['O Daniel Fernandes decidiu dar um mergulhito no rio hoje que está sol', 'Era um vez uma pessoa que se chamava Helena, que estudava com o Daniel Fernandes, este último que era uma pessoa muito aplicada']

def find_related_words(nome, noticias):
	words = []
	totalN = 0
	for noticia in noticias:
		nomeM = re.sub(r' ', r'=', nome)
		(noticia, n) = re.subn(nome, nomeM, noticia)
		totalN = totalN + n
		total = re.split(r'[\p{punct}\s]*', noticia)

		for i in range(0, len(total)):

			if total[i] == nomeM and i < 5:
				words = words + total[0:i]
				words = words + total[i+1:11]
			elif total[i] == nomeM and len(total) - 5 < i:
				words = words + total[i+1:len(total)]
				words = words + total[len(total)-11:i]
			elif total[i] == nomeM:
				words = words + total[i-5:i]
				words = words + total[i+1:i+6]

	return (words, totalN)

def calc_pol(nome, noticias, polaridade):
	
	totalPol = 0

	(words, totalN) = find_related_words(nome, noticias)

	for w in words:
		totalPol += polaridade.get(w, 0)

	print(totalN)
	print(totalPol)

	return totalPol/totalN

print(calc_pol(nome, noticias, polaridade))