#!/usr/bin/python3

import regex as re
from collections import Counter, defaultdict
import random

############################# Questao 1 ###########################
def max_diff(lista):
    min = max = lista[0]
    for elem in lista:
        if elem > max:
            max = elem
        elif elem < min:
            min = elem
        else:
            pass

    return abs(max-min)

#ou

def max_diff2(lista):
    return abs(max(lista) - min(lista))

print(max_diff([1,1,3,5,2]))
print(max_diff2([1,1,3,5,2]))


def count_char_ocurr(string):
    dic = Counter()
    for c in string:
        dic[c] += 1
    return dict(dic)

print(count_char_ocurr('TESTE DE SPLN'))

############################# Questao 2 ###########################

def filtro(texto):
    tokens = texto.split('\n\n')
    lista = process_tokens(tokens)
    return '\n\n'.join(lista)

def process_tokens(paragrafos):
    res = []
    for parag in paragrafos:
        aux = re.sub(r'(-)\n',r'',parag)
        aux2 = re.sub(r'\n',r' ',aux)
        res.append(aux2)
    return res

texto = '''Ele mesmo costuma dizer que\nera simplesmente\nmas nunca 
admitiu.\n\nParte do seu rendimento ia-se-\n-lhe por entre os dedos enterne-\ncidos que mais valia.'''

print(filtro(texto))

############################# Questao 3 ###########################

def questao3_a(text):
    aux = re.sub(r'^(\s*)(\p{Ll})', lambda x: x[1] + x[2].upper(), text)
    return re.sub(r'(?<=[.!?:;])(\s+)(\p{Ll})', lambda x: x[1] + x[2].upper(), aux)

texto = 'hoje estava um dia muito bonito sem duvida que, Daniel Fernandes, decidiu dar um mergulhito no rio.\n   era um vez uma pessoa que se chamava helena, que estudava com o daniel fernandes, este último que era uma pessoa muito aplicada.'
print(questao3_a(texto))

def questao3_b(text):
    dic = defaultdict(Counter)
    palavras = re.split(r'[\p{punct}\s]+', text)
    for pal in palavras:
        dic[pal.lower()][pal]+=1
    return dic

def questao3_extra(texto, textoBom):
    textoInicios = questao3_a(texto)
    dic = questao3_b(textoBom)
    return re.sub(r'\b(\p{L}+)\b', lambda x: escolhePalavra(x[1], dic), textoInicios)

def escolhePalavra(pal, dic):
    pal_norm = pal.lower()
    if(pal in dic[pal_norm]):
        return pal
    else:
        return dic[pal_norm].most_common()[0][0]
        #return random.choices(list(dic[pal_norm]), list(dic[pal_norm].values()))[0]

textoBom = 'Hoje estava um dia muito bonito sem duvida que, Daniel Fernandes, decidiu dar um Mergulhito no rio.\n   Era um vez uma pessoa que se chamava Helena, que estudava com o Daniel Fernandes, este Último que era uma pessoa muito aplicada.'
print(questao3_extra(texto, textoBom))

############################# Questao 4 ###########################

def questao4(nome, polaridades, noticias):
    nomeAlterado = alteraNome(nome)
    sum_pol = 0
    sum_ocorr = 0
    for noticia in noticias:
        (pol, ocorr) = process_noticia(nome, nomeAlterado, polaridades, noticia)
        sum_pol += pol
        sum_ocorr += ocorr
    
    print(sum_ocorr)
    print(sum_pol)
    
    return sum_pol / sum_ocorr

def process_noticia(nome, nomeA, polaridades, noticia):
    regex = r'\b(' + nome + r')\b'
    noticia = re.sub(regex, lambda x: alteraNome(x[1]), noticia)
    palavras = re.split(r'[\s\p{punct}]+', noticia)
    indices = [i for i in range(0, len(palavras)) if palavras[i] == nomeA]
    sum_polaridades = 0

    for i in indices:
        palInd = getIndexes(i, palavras)
        for ind in palInd:
            sum_polaridades += polaridades.get(palavras[ind],0)
            
    return (sum_polaridades, len(indices))

def getIndexes(i,palavras):
    j = max(i-5, 0)
    k = min(i+5, len(palavras))
    diffL = abs(i-j)
    diffU = abs(k-i)
    palInd = None
    if(diffL < 5):
        palInd = range(j,i)
        palInd += range(i+1, k+1+(5-diffL))
    elif(diffU < 5):
        palInd = range(i+1, k+1)
        palInd = range(j-(5-diffU), i) + palInd
    else:
        palInd = list(range(j,k+1))
        palInd.pop(5)
    return palInd
    
def alteraNome(nome):
    return re.sub(r' ', r'=', nome)

polaridades = {
    'muito': 1,
    'bonito': 1,
    'sem': -1,
    'duvida': -1,
    'que': 0,
    'decidiu': 0,
    'dar': 1,
    'um': 0,
    'mergulhito': 1,
    'no': 0,
    'Helena': -1,
    'estudava': -1,
    'com': 0,
    'o': 0,
    'este': 0,
    'último': 1,
    'era': 1,
    'uma': 0,
    }
noticias = ['Hoje estava um dia muito bonito sem duvida que, Daniel Fernandes, decidiu dar um mergulhito no rio', 'Era um vez uma pessoa que se chamava Helena, que estudava com o Daniel Fernandes, este último que era uma pessoa muito aplicada']

print(questao4('Daniel Fernandes', polaridades, noticias))

## proposta leninha

def find_related_words(nome, noticias, polaridade):
	words = []
	totalN = 0
	for noticia in noticias:
		nomeM = re.sub(r' ', r'=', nome)
		(noticia, n) = re.subn(nome, nomeM, noticia)
		totalN = totalN + n
		total = re.split(r'[\p{punct}\s]*', noticia)

		for i in range(0, len(total)):

			if total[i] == nomeM and i < 5:
				words = words + total[0:i]
				words = words + total[i+1:11]
			elif total[i] == nomeM and len(total) - 5 < i:
				words = words + total[i+1:len(total)]
				words = words + total[len(total)-11:i]
			elif total[i] == nomeM:
				words = words + total[i-5:i]
				words = words + total[i+1:i+6]

	totalPol = 0

	for w in words:
		totalPol += polaridade.get(w, 0)

	return totalPol/totalN


############################# Questao 5 ###########################

def questao5(string1, string2):
    lista1 = re.split(r'[\p{punct}\s]+', string1)
    lista2 = re.split(r'[\p{punct}\s]+', string2)
    dic = {}

    for i in range(0, len(lista1)):
        if lista1[i] != lista2[i]:
            dic[lista1[i]] = lista2[i]
    return dic

string1 = 'As inundacões provocaram graves damnos na pharmácia.'
string2 = 'As inundacões provocaram graves danos na farmácia.'
print(questao5(string1, string2))




