import fileinput
import regex as re
from collections import Counter, defaultdict
import random

dict_pt_en = {
	'carro':'car'
}

accoes = [
	(r'és um (\w+)', [
		lambda x: f'{x} és tu!',
		lambda x: f'Tu é que és {x}',
		'Quem diz é quem é!'
		]),
	(r'.', ['Não percebi, fala direito!'])
]

def print_ing(x):
	return dict_pt_en.get(x, 'UNK')


def bot_responde(accoes, frase):
	for (p, f) in accoes:
		match = re.match(p, frase)
		if match:
			accao = random.choice(f)
			if callable(accao):
				print(accao(match.group(1)))
			else:
				print(accao)
		break

print(print_ing('carro'))
bot_responde(accoes, "és um burro")


f = lambda x: x + 1

print(f(f(2)))