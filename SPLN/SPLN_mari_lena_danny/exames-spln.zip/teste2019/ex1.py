# a)

def max_diff(numeros):
	if len(numeros) < 2:
		print("A lista não tem pelo menos dois elementos!")
	#elif any(n < 0 for n in numeros):
	#	print("A lista contém números negativos!")
	else:
		return abs(max(numeros) - min(numeros))

def count_char_occur(string):
	dictionary = {}

	for char in string:
		dictionary[char] = dictionary.get(char, 0) + 1

	return dictionary


print(max_diff([1,1,3,5,2]))
print(count_char_occur("TESTE DE SPLN"))