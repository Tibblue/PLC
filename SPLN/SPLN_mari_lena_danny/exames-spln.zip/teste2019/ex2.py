import re



def fix_lines(string):

	aux = re.sub(r'(-)\n', r'', string)
	texto_r = re.sub(r'(?<=[^\n])\n(?=[^\n])', r' ', aux)

	return texto_r

texto = '''Ele mesmo costuma tin-\nham dizer que\nera simplesmente\nmas nunca admitiu.\n\nParte do seu rendimento ia-se-\n-lhe por entre os dedos enterne-\ncidos que mais valia.'''

print(fix_lines(texto))
