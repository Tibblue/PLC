import regex as re


# a) 

dict1 = {
	'a': 3,
	'c': 3,
	'e': 6
}

dict2 = {
	'a': 2,
	'c': 8,
	'd': 9
}

def baginter(dict1, dict2):
	inter = {}

	for (k, v) in dict1.items():
		if k in dict2:
			v2 = dict2.get(k)
			inter[k] = min(v, v2)

	return inter

# b)

def extend(idd):
	idd = re.sub(r'([A-Z])', r' \1', idd)
	idd = re.sub(r'([24])', r' \1 ', idd)
	id_list = re.split(r'[_ ]', idd)
	result = []

	for w in id_list:
		if w == "2":
			result.append("to")
		elif w == "4":
			result.append("for")
		elif w.istitle():
			result.append(w.lower())
		else:
			result.append(w)

	return ' '.join(result)

print(baginter(dict1, dict2))
print(extend("my_idCompareSimple4sort"))