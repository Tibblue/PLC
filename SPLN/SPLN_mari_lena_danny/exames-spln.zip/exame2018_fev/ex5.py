import sys
import getopt
import os
import fileinput
import regex as re

ops, args = getopt.getopt(sys.argv[1:], '')

nr_file = 1
nr_chapter = 0
nr_sec = 0
nr_sub = 0

for file in args:
	print("FICHEIRO NR" + str(nr_file) + " " + "=" * 7)
	with open(file, 'r') as f:
		data = f.readlines()
	for line in data:
		if re.match(r'\\title{[^}]*}', line):
			title = re.search(r'\\title{([^}]*)}', line)
			print("Título: " + title.group(1))
		elif re.match(r'\\chapter{[^}]*}', line):
			nr_chapter = nr_chapter + 1
			nr_sec = 0
			chapter =  re.search(r'\\chapter{([^}]*)}', line)
			print(str(nr_chapter) + " - " + chapter.group(1))
		elif re.match(r'\\section{[^}]*}', line):
			nr_sec = nr_sec + 1
			nr_sub = 0
			section = re.search(r'\\section{([^}]*)}', line)
			print(str(nr_chapter) + "." + str(nr_sec) + " - "+ section.group(1))
		elif re.match(r'\\subsection{[^}]*}', line):
			nr_sub = nr_sub + 1
			sub = re.search(r'\\subsection{([^}]*)}', line)
			print(str(nr_chapter) + "." + str(nr_sec) + "." + str(nr_sub) + " - " + section.group(1))
	print("=" * 21)