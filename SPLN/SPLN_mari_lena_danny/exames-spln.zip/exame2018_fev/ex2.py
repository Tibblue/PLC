import regex as re

def break_phrases(phrases):
	aux = re.sub(r'(?<!sr|dr|d|prof)(\.)(?!\s*[a-z])', r'\1\n', phrases)
	return re.sub(r'\n\s*', r'\n', aux)

print(break_phrases("Isto é uma frase normal. Isto é outra frase normal que fala da d. Fernanda. Outros . para não considerar. Mais a falar do prof. Marcelo que é o nosso presidente"))