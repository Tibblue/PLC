# coding=utf-8

import sys
import getopt
import os
import fileinput
import re

texto = '''
<meta>
jornal publico
</meta>
<s>
Estes	este	DET		outras cenas
temas	tema	N	outras mais
serão	ser	V		mais ainda
</s>
<s>
Estes	este	DET	outras cenas
é	tema	V	outras mais
inacreditável	ser	ADJ	mais ainda
</s>
'''

def calc_times(texto):
	times = {}

	segmentos = re.findall(r'(?<=<s>\n)[^<]*(?=\n</s>)', texto)

	for segmento in segmentos:
		lines = re.split(r'\n', segmento)
		for line in lines:
			pal = re.split(r'\t', line)
			aux = pal[1] + "-" + pal[2]
			times[aux] = times.get(aux, 0) + 1

	print(times)


calc_times(texto)

def print_text(texto):
	lines = re.split(r'\n', texto)

	for i in range(0, len(lines)):
		if lines[i] == "<meta>":
			print("==" + lines[i+1])
			nr_line = 1
		elif lines[i] == "<s>":
			save = []
			for o in range(i+1, len(lines)):
				if lines[o] == "</s>":
					print(str(nr_line) + ". " + ' '.join(save))
					i = o
					nr_line = nr_line + 1
					break
				else:
					cenas = re.search(r'([^\t]*).*', lines[o])
					save.append(cenas.group(1))

print_text(texto)