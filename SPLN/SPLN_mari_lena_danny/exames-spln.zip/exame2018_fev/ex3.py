import sys
import getopt
import os
import fileinput
import regex as re

def calc_trigrams(corpus):
	trigrams = {}

	corpus = re.sub(r'\p{punct}', r' ', corpus)
	corpus = re.sub(r'\s+', r' ', corpus)

	list_grams = [tuple(corpus[i:i+3]) for i in range (0, len(corpus) - 2)]

	for gram in list_grams:
		trigrams[''.join(gram)] = trigrams.get(''.join(gram), 0) + 1

	return trigrams

def tabela(lang, corpus):
	trigrams = calc_trigrams(corpus)
	print("#trigrama\t" + lang)
	for (k, v) in trigrams.items():
		value = v/1000000
		print(''.join(k) + "\t" + str(value))

corpus = "Este é um corpus só que não é nada grande por isso no fundo é como se não fosse realmente um corpus. Os corpus tem de ser grandes."
#tabela('pt', corpus)


def calc_lang(texto, tabtrig):
	pt = {}
	en = {}

	with open('test.txt', 'r') as f:
		data = f.readlines()[1:]


	for line in data:
		cenas = re.search(r'([^\t]*)\t([^\t]*)\t([^\t]*).*', line)
		pt[cenas.group(1)] = cenas.group(2)
		en[cenas.group(1)] = cenas.group(3)

	trigrams = calc_trigrams(texto)

	sum_pt = 0
	sum_en = 0

	for (k, v) in trigrams.items():
		sum_pt = sum_pt + float(pt.get(k, 0)) + 1
		sum_en = sum_en = float(en.get(k, 0)) + 1

	if sum_pt > sum_en:
		return 'PT'
	else:
		return 'EN'

corpus2 = "Este é"

print(calc_lang(corpus2, 'test.txt'))