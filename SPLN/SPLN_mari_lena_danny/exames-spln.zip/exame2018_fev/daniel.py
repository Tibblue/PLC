#!/usr/bin/python3

import regex as re
from collections import Counter, defaultdict
import random
import fileinput

dic1 = {'a': 3, 'c': 3,'e': 6}
dic2 = {'a': 2, 'c': 3,'d': 9}

def questao1_a(dic1, dic2):
    dic = {}
    for (k,v) in dic1.items():
        if k in dic2:
            dic[k] = min(v,dic2[k])
    return dic

print(questao1_a(dic1, dic2))

def questao1b(texto):
    aux = re.sub(r'_', r' ', texto)
    aux = re.sub(r'(?<=\p{Ll})(\p{Lu})', lambda x: ' ' + x[1].lower(), aux)
    aux = re.sub(r'(2|4)', lambda x: ' to ' if x[1] == '2' else ' for ', aux)
    return aux

print(questao1b('my_idCompareSimple4sort2youMaFrend'))

#################### Questao 2 #################

def filtro(texto):
    res = []
    paragrafos = re.split(r'\n\n+', texto)
    for parag in paragrafos:
        linhas = quebra_linhas(parag)
        res.append('\n'.join(linhas))
    return '\n\n'.join(res)

def quebra_linhas(parag):
    res = []
    linhas = re.split(r'(?<=\.)\s*(?=[^\p{Ll}])', parag)
    for linha in linhas:
        res.append(re.sub(r'\n', r' ', linha))
    return res

texto = '''Ele mesmo costuma dizer que\nera simplesmente\nmas nunca 
admitiu.\n\n\nParte do seu rendimento prof. por entre os dedos enternecidos que mais valia.'''

print(filtro(texto))

########################### Questao 3 ####################

def questao3a(corpus):
    dic = Counter()
    res = {}
    for line in fileinput.input(corpus):
        line = re.sub(r'[\p{punct}\s]+', ' ', line)

        for i in range(0, len(line) - 3 + 1):
            dic[line[i:i+3]] += 1

    for trig in dic:
        res[trig] = dic[trig] / 1000000
    return res

#print(questao3a('cenas.txt'))

#with open('cenas2.txt', 'r') as tab:
#    dic = {}
#    next(tab)
#    for line in tab:
#        row = re.split(r'\s+', line)
#        dic[row[0]] = {'pt': row[1], 'en': row[2]}

#rint(dic)

########################### Questao 5 ####################

def indexar_latex(texto):
    lista = re.findall(r'(title|chapter|section|subsection)\{(.+?)\}', texto)
    print(lista)
    chapter = section = subsection = 0

    for (elem, name) in lista:

        if(elem == "title"):
            print(name)
        elif(elem == "chapter"):
            chapter += 1; section = subsection = 0
            print('\t' + str(chapter) + '. ' + name)
        elif(elem == "section"):
            section += 1 ; subsection = 0
            print('\t\t' + str(chapter) + '.' + str(section) + '. ' + name)
        elif(elem == "subsection"):
            subsection += 1
            print('\t\t\t' + str(chapter) + '.' + str(section) + '.' + str(subsection) + '. ' + name)
        
texto ='''
\\title{"Um gato muito mau"}ola
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\chapter{"Um gato muito mau 1"}ola
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\section{"Um gato muito mau 1.1"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\section{"Um gato muito mau 1.2"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\subsection{"Um gato muito mau 1.2.1"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\subsection{"Um gato muito mau 1.2.3"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\chapter{"Um gato muito mau 2"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\section{"Um gato muito mau 2.1"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\section{"Um gato muito mau 2.2"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\subsection{"Um gato muito mau 2.2.1"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
\\subsection{"Um gato muito mau 2.2.3"}
dlajkda lija dahdi kaid aidj llahd ld
dakj dakj kdaj laddlakda
'''

indexar_latex(texto)

########################### Questao 6 ####################

def anotar (ficheiro):
    f = open(ficheiro, 'r')
    texto = f.read()
    segmentos = re.findall(r'(?<=\<s\>)[^<]+', texto)
    dic = Counter()
    for segmento in segmentos:
        rows = re.split(r'\n', segmento.strip())
        for row in rows:
            cols = re.split(r'\s+', row)
            dic[cols[1] + '-' + cols[2]] += 1
    for (lc, ocorr) in dic.items():
        print(lc + '\t' + str(ocorr))

#anotar('cenas3.txt')

def reconstruir (ficheiro):
    f = open(ficheiro, 'r')
    texto = f.read()
    meta = re.search(r'\<meta\>([^<]+)', texto)
    print('==' + meta[1].strip())
    segmentos = re.findall(r'\<s\>([^<]+)', texto)
    i = 0
    for segmento in segmentos:
        i += 1
        frase = re.findall(r'(?<=\n)[^\s]+', segmento)
        res = ' '.join(frase)
        print(str(i) + '. ' + res)

reconstruir('cenas3.txt')

rev = 'ola'

print(list(reversed(rev)))