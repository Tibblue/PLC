#include <stdio.h>
int main() {
    int i, j, rows;

    printf("Enter number of rows: ");
    scanf("aidna outra %d",&rows);

    for(i=1; i<=rows; ++i) {
        for(j=1; j<=i; ++j) {
            printf("outra string");
        }
        printf("=========");
    }
    return 0;
}