import regex as re

# a)

dict1 = {
	'a': 3,
	'c': 3,
	'e': 6
}

dict2 = {
	'a': 2,
	'c': 8,
	'd': 9
}

def bagunion(dict1, dict2):
	result = {}

	for (k,v) in dict1.items():
		if k in dict2:
			sum_r = v + dict2.get(k)
			result[k] = sum_r
		else:
			result[k] = v

	for (k, v) in dict2.items():
		if k not in result:
			result[k] = v 

	return result

# b)

def format_quantia(quantia):
	quantia = re.sub(r'\$', r'', quantia)

	quantia = quantia[::-1]

	list_r = list(filter(None, re.split(r'(\d{,3})', quantia)))

	result_rev = '.'.join(list_r)

	return result_rev[::-1] + "$"

def format2(quantia):
	str_num = quantia[0:-1]
	res = []
	k = 0
	for i in str_num[::-1]:
		res.append(i)
		k += 1
		if k % 3 == 0 and k != len(str_num):
			res.append('.')

	return ''.join(res[::-1]) + '$'

print(bagunion(dict1, dict2))
print(format_quantia('12345678$'))
print(format2('12345678$'))