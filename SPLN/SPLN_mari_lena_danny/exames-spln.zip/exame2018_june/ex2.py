import regex as re

# a)

def classify(text, file):
	palavras = {}

	with open(file, 'r') as f:
		data = f.readlines()

	for line in data:
		colunas = re.search(r'(\S*)\s*(\S*)', line)
		k = colunas.group(1)
		v = colunas.group(2)
		palavras[k] = palavras.get(k, []) + [v]

	sum_pt = 0
	sum_br = 0

	words = re.split(r'[\p{punct}\s]+', text)

	for word in words:
		if word in palavras['pt_PT']:
			sum_pt += 1
		elif word in palavras['pt_BR']:
			sum_br += 1

	if sum_pt > sum_br:
		print('pt_PT')
	else:
		print('pt_BR')

br_phrase = "o trem partiu ontem de lisboa. a galera está toda feliz"
pt_phrase = "o comboio partiu ontem de lisboa. o pessoal está todo feliz"

classify(br_phrase, 'lista_negra.txt')
classify(pt_phrase, 'lista_negra.txt')

# b)

def lista_negra_builder(file_pt, file_br):
	result = []

	with open(file_pt, 'r') as f1:
		data_pt = f1.read()
	with open(file_br, 'r') as f2:
		data_br = f2.read()

	lista_pt = re.split(r'[\p{punct}\s]+', data_pt)
	lista_br = re.split(r'[\p{punct}\s]+', data_br)

	for word in lista_pt:
		if word not in lista_br:
			result.append(('pt_PT', word))
	for word in lista_br:
		if word not in lista_pt:
			result.append(('pt_BR', word))

	with open('lista_negra_generated.txt', 'w') as f:
		for (var, pal) in result:
			f.write(var + "\t" + pal + "\n")

lista_negra_builder('file_pt.txt', 'file_br.txt')