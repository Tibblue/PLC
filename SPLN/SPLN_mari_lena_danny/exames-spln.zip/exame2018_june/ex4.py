
import regex as re

def tradC(programa_c):
	with open(programa_c, 'r') as f:
		data = f.read()

	list_string = re.findall(r'\"[^"]*\"', data)

	for string in list_string:
		print("=" * 21)
		print("ORIG: " + string)
		print("TRAD: " + string)

tradC('example.c')