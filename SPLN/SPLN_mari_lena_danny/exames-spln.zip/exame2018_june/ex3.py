import regex as re

test_text = '''44 	o 		o 		DAOMSO 		wowowowoowowoowow
45 	capital	capital	NCFSOOO		wowowowoowoowowow
46	fica	ficar	VMIP3SO		nonononono'''

def transform(text):
	result_list = []

	lines = re.split(r'\n', text)

	for line in lines:
		tmp = re.search(r'\S*\s*(\S*)\s*(\S*)\s*(\S*).*', line)
		c2 = tmp.group(1)
		c3 = tmp.group(2)
		c4 = re.sub(r'[O]*$', r'', tmp.group(3))

		result_list.append(c2 + "=" + c3 + "+" + c4)

	return ' '.join(result_list)

print(transform(test_text))

