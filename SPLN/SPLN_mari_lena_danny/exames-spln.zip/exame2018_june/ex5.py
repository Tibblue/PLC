import regex as re

def livros(ficheiro):
	dictionary = {}

	with open(ficheiro, 'r') as f:
		lista = f.readlines()

	for line in lista:
		if re.match(r'.{5,}', line):
			value = dictionary.get(line, 1)
			if value == 1:
				print(line, end='')
			else:
				print("==" + str(value) + "==" + line, end='')
			dictionary[line] = value + 1
		else:
			print(line, end='')

livros('livros.txt')