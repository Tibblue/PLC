import setuptools

setuptools.setup(
    name='spln_elastic',
    version='0.0.1',
    packages=setuptools.find_packages(),
    entry_points={
    },
)
