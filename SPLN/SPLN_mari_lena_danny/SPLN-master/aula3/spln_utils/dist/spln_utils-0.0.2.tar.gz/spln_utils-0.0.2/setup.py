import setuptools

setuptools.setup(
	name='spln_utils',
	version='0.0.2',
	packages=setuptools.find_packages(),
)