#!/usr/bin/python3

from .paragraphs import normText