
Write a program to find numerals in text (e.g. _200 406_) and replace
them by their spelled out version (_duzentos mil, quatrocentos e
seis_), in Portuguese.
