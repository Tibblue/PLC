#!/bin/bash
mongoimport.exe -d myapi -c movies --file movies.json --jsonArray