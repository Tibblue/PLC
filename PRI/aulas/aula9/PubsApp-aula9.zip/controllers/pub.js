var Pub = require('../models/pub')

const Pubs = module.exports

// Devolve a lista de pubs em JSON
Pubs.list = () => {
    return Pub
        .find()
        .sort({year: -1})
        .exec()
}

Pubs.count = () => {
    return Pub
        .countDocuments()
        .exec()
}

Pubs.coAuthored = a => {
    var coaut = new RegExp(a, "i")
    return Pub
        .find({authors: coaut})
        .sort({year: -1})
        .exec()
}