$(()=>{
    $('#paras').load('http://localhost:4008/para')

    $('#adicionar').click(e => {
        e.preventDefault()
        $('#paras').append('<li>' + $('#texto').val() + '</li>')
        ajaxPost()
    })

    function ajaxPost(){
        $.ajax({
            type: "POST",
            contentType: "application/json",
            url: "http://localhost:4008/para/guardar",
            data: JSON.stringify({para: $('#texto').val()}),
            success: p => alert('Parágrafo gravado com sucesso: ' + p),
            error: e => {
                alert('Erro no post: ' + JSON.stringify(e))
                console.log('ERRO: ' + e)
            }
        })
        $('#texto').val('')
    }
})