var express = require('express');
var router = express.Router();
var passport = require('passport')

/* GET home page. */
router.get('/', function(req, res, next) {
  console.log('Estou no router e a sessão é: ' + req.sessionID)
  res.render('index');
});

router.get('/login', function(req, res, next) {
  console.log('Estou no GET login')
  res.render('login');
});

/* router.post('/login', function(req, res, next) {
  console.log('POST login')
  passport.authenticate('local', (err, user, info) => {
    console.log('Autenticando...')
    console.dir(user)
    console.dir(info)
    if(info) {return res.send(info.message)}
    if(err) {return next(err)}
    if(!user) {return res.redirect('/login')}
    req.login(user, erro => {
      if(erro) {return next(erro)}
      return res.redirect('/authrequired')
    })
  })(req, res, next);
}); */

router.post('/login', passport.authenticate('local', { successRedirect: '/authrequired',
        failureRedirect: '/login',
        failureFlash: 'Utilizador ou password inválio(s)...',
        successFlash: 'Utilizador autenticado com sucesso.'}
))

/* router.get('/authrequired', (req,res) => {
  if(req.isAuthenticated()){
    res.send('Atingiste a área autenticada!')
  }
  else{
    res.redirect('/')
  }
}) */

// Proteger com middleware
function verificaAutenticacao(req, res, next){
  if(req.isAuthenticated()) next()
  else res.redirect("/login")
}

router.get('/protegida', verificaAutenticacao, (req,res) => {
  res.send('Atingiste a área protegida!!!')
})

module.exports = router;
